<!DOCTYPE html>
<html>
<head>
	<title>Index Page</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>
	<div class="container">
		<div style="margin-bottom: 120px">
			
		</div>
		<div class="row jumbotron">
			<div class="col-md-12 text-center" style="font-weight: bold">
				@include('alert')
			</div>
			<div class="col-md-12">
				<h4 class="text-center" style="font-weight: bold">User Login & Registration Page</h4>
			</div>
			<br>
			<br>
			<br>
			<br>
			<br>
			<div class="col-md-12">
				<div class="col-md-6">
				    <form action="sign-up" method="post" class="form-horizontal">
					     {{@csrf_field()}}
					        <div class="form-group">
						        <label class="control-label col-md-3" for="email">E-Mail</label>

						        <div class="col-md-9">
                                     <input type="text" class="form-control" id="email" name="email" placeholder="Enter E-Mail..">
                                </div>
					        </div>
					        <div class="form-group">
						         <label class="control-label col-md-3" for="pwd">Password</label>

						         <div class="col-md-9">
                                     <input type="text" class="form-control" id="pwd" name="password" placeholder="Enter Password..">
                                </div>
					       </div>
					        <div class="form-group">
						         <label class="control-label col-md-3" for="c-pwd">C-Password</label>

						         <div class="col-md-9">
                                     <input type="text" class="form-control" id="c-pwd" name="c_password" placeholder="Enter Confirm Password..">
                                </div>
					        </div>
					        <div class="col-md-12 text-center">
						        <input type="submit" name="sign-up" class="btn btn-primary" value="Sign-up">
					        </div>
				    </form>
					
			    </div>

			    <div class="col-md-6">
			    	<form action="login" method="post" class="form-horizontal">
					     {{@csrf_field()}}
					        <div class="form-group">
						        <label class="control-label col-md-3" for="email">E-Mail</label>

						        <div class="col-md-9">
                                     <input type="text" class="form-control" id="email" name="email" placeholder="Enter E-Mail..">
                                </div>
					        </div>
					        <div class="form-group">
						         <label class="control-label col-md-3" for="pwd" >Password</label>

						         <div class="col-md-9">
                                     <input type="text" class="form-control" id="pwd" name="password" placeholder="Enter Password..">
                                </div>
					       </div>
					       
					        <div class="col-md-12 text-center">
						        <input type="submit" name="login" class="btn btn-primary" value="Login">
					        </div>
				    </form>
			    </div>
			</div>
		</div>
		
	</div>

</body>
</html>