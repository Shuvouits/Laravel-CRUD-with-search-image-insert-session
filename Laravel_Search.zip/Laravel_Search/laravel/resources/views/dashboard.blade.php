<!DOCTYPE html>
<html>
<head>
	<title>Laravel Search Application With JavaScript</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('style.css')}}">
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">
				<div class="col-md-10">
				     <h4 class="text-center" style="font-weight: bold">Welcome to <span style="color:red"> {{$session_email}} </span></h4>
			   </div>
			   <div class="col-md-2">
					<a href="logout" class="btn btn-info">Logout</a>
				</div>
			</div>
			<br>
			<br>
			<br>
			<br>
            


			
				<div class="col-md-10">
					<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">
				</div>
				<div class="col-md-2">
					<span style="margin-left:45px">
					     <a href="" class="btn btn-default" data-toggle="modal" data-target="#myModal">
						     <i class="fa fa-plus"></i> Add-Data
					    </a>
				    </span>
				</div>
			    
			<br>
			<br>
			<br>

			<div class="col-md-12">
				<table class="table table-bordered table-striped table-hover" id="myTable">
					
					<tr>
						<th class="text-center">Name</th>
						<th class="text-center">Country</th>
						<th class="text-center">Category</th>
						<th class="text-center">Image</th>
						<th class="text-center">Add-Person</th>
						<th class="text-center">Action</th>
					</tr>

					@foreach($data as $item)
					<tr>
						
						
						<td class="text-center">{{$item->name}}</td>
						<td class="text-center">{{$item->country}}</td>
						<td class="text-center">{{$item->category}}</td>
						<td class="text-center"><img src="{{asset('images/'.$item->image)}}" style="width: 50px; height: 50px"></td>
						<td class="text-center">{{$item->add_person}}</td>
						<td class="text-center">
							<span>
							     <a href="" data-toggle="modal" data-target="#edit{{$item->id}}">
							     	<i class="fa fa-pencil"></i>
							     </a>
						    </span>
						    <span style="margin-left:20px">
							     <a href="#" data-toggle="modal" data-target="#delete{{$item->id}}"><i class="fa fa-trash"></i></a>
						    </span>
						</td>
					</tr>
					@endforeach
				</table>
			</div>

			
			
		</div>
	</div>

	

<!-- Insert Data -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center" style="font-weight: bold">Add Information Data</h4>
        <br>
        <br>

        <form method="post" action="insert" class="form-horizontal" enctype="multipart/form-data">
        	{{@csrf_field()}}
        	<div class="form-group">
			    <label class="control-label col-md-2" for="name">Name</label>

				    <div class="col-md-10">
                         <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name..">
                    </div>
			</div>
			<div class="form-group">
			    <label class="control-label col-md-2" for="country">Country</label>

				    <div class="col-md-10">
                         <input type="text" class="form-control" id="country" name="country" placeholder="Enter Country..">
                    </div>
			</div>
			<div class="form-group">
			    <label class="control-label col-md-2" for="category">Category</label>

				    <div class="col-md-10">
                         <input type="text" class="form-control" id="category" name="category" placeholder="Enter Category..">
                    </div>
			</div>
        	<div class="form-group">
			    <label class="control-label col-md-2" for="image">Image</label>

				    <div class="col-md-10">
                         <input type="file" class="form-control" id="image" name="image">
                    </div>
			</div>
			
			
			

			<input type="hidden" name="email" value="{{$session_email}}">
			<input type="hidden" name="add_person" value="{{$session_email}}">
			
			<div class="col-md-12 text-center">
				<input type="submit" name="submit" class="btn btn-primary">
			</div>
        	
        	
        	
        </form>

      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<!-- Delete Data---->



@foreach($data as $item)
<div id="delete{{$item->id}}" class="modal fade" role="dialog">

  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center" style="font-weight: bold">Are You Sure?</h4>
        
        <form method="post" action="delete">
        
        	{{@csrf_field()}}

        	
        	<input type="hidden" name="email" value="{{$session_email}}">
        	<input type="hidden" name="id" value="{{$item->id}}">

        	<input type="submit" name="submit" class="btn btn-primary" value="Delete">

        </form>

      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
@endforeach





<!----Edit Data--->


@foreach($data as $item)
<div id="edit{{$item->id}}" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center" style="font-weight: bold">Edit Your Data</h4>

         <form method="post" action="edit" class="form-horizontal" enctype="multipart/form-data">
        	{{@csrf_field()}}
        	<div class="form-group">
			    <label class="control-label col-md-2" for="name">Name</label>

				    <div class="col-md-10">
                         <input type="text" class="form-control" id="name" name="name" value="{{$item->name}}">
                    </div>
			</div>
			<div class="form-group">
			    <label class="control-label col-md-2" for="country">Country</label>

				    <div class="col-md-10">
                         <input type="text" class="form-control" id="country" name="country" value="{{$item->country}}">
                    </div>
			</div>
			<div class="form-group">
			    <label class="control-label col-md-2" for="category">Category</label>

				    <div class="col-md-10">
                         <input type="text" class="form-control" id="category" name="category" value="{{$item->category}}">
                    </div>
			</div>
        	<div class="form-group">
			    <label class="control-label col-md-2" for="image">Image</label>

				    <div class="col-md-10">
                         <input type="file" class="form-control" id="image" name="image" required>
                         <img src="{{asset('images/'.$item->image)}}" style="width:50px; height: 50px">
                    </div>
			</div>
			
			
			

			<input type="hidden" name="email" value="{{$session_email}}">
			<input type="hidden" name="add_person" value="{{$session_email}}">

			<input type="hidden" name="id" value="{{$item->id}}">
			
			<div class="col-md-12 text-center">
				<input type="submit" name="submit" class="btn btn-primary">
			</div>
        	
        	
        	
        </form>


      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
@endforeach

	<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>