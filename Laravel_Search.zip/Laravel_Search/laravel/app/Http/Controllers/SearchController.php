<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;

class SearchController extends Controller
{
    public function index(){
        $get_data = "SELECT * FROM users";
        $run_data = DB::select($get_data);
        return view('search')->with(compact('run_data'));
    }

    public function signUp(Request $req)
    {
        $email = $req->input('email');
        $password = $req->input('password');
        $c_password = $req->input('c_password');
        if($password == $c_password)
        {
            $get_data = "SELECT * FROM users WHERE email = '$email' ";
            $run_data = DB::select($get_data);
            $count = count($run_data);
            if($count<1){
                $insert_data = "INSERT INTO users (email,password) VALUES ('$email','$password')";
                $run_data = DB::select($insert_data);
                return redirect('/')->with('success','Sign-Up Successfully Completed');
            }else{
                return redirect('/')->with('error','This Email are already Used By another user');

            }  
            
        }else{
            return redirect('/')->with('error','Confirmed Password Doesnot Match');
        }
    }

    public function login(Request $req){
        $email = $req->input('email');
        $password = $req->input('password');

        $get_data = "SELECT * FROM users WHERE email='$email' AND password=$password ";
        $run_data = DB::select($get_data);
        $count = count($run_data);
        if($count==1){

            $view_data = "SELECT * FROM information";
            $run_view_data = DB::select($view_data);
            $data = $run_view_data;

            session()->put('email',$email);
            $session_email = session()->get('email');
            return view('dashboard',compact('session_email','data'));
        }else{
            return redirect('/')->with('error','Eamil or Password is not Correct');
        }
    }

    public function logout(){
        Session::flush();
        return redirect('/');
    }

    public function insert(Request $request)
    {
        $name = $request->input('name');
        $country = $request->input('country');
        $category = $request->input('category');
       // $image = $request->input('image');
        $add_person = $request->input('add_person');
        $session_email = $request->input('email');

        //upload Image

          $msg = "";
	     $image = $_FILES['image']['name'];
	     $target = "images/".basename($image);

	     if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		    $msg = "Image uploaded successfully";
  	     }else{
  		    $msg = "Failed to upload image";
  	     }

        $insert_data = "INSERT INTO information (name,country,category,add_person,image) VALUES ('$name','$country','$category','$add_person','$image')";
        $run_data = DB::select($insert_data);

       

        //session()->put('insert','Data Insert Success');
        //$insert = session()->get('insert');

    

        $view_data = "SELECT * FROM information";
        $run_view_data = DB::select($view_data);
        $data = $run_view_data;

        return view('dashboard', compact('session_email','data'));
    }

    public function delete(Request $request){

        
         
         $id = $request->input('id');
         //print_r($id);
          $delete_data = "DELETE FROM information WHERE id=$id ";
          $run_data = DB::select($delete_data);
        

        
        $session_email = $request->input('email');

        $view_data = "SELECT * FROM information";
        $run_view_data = DB::select($view_data);
        $data = $run_view_data;

       // session()->put('delete','Data hasbenn deleted Successfully');
       // $delete = session()->get('delete');

        return view('dashboard', compact('session_email','data'));

    }

    public function edit(Request $request){
        $id = $request->input('id');
        $country = $request->input('country');
        $category = $request->input('category');
        $name = $request->input('name');
        $add_person = $request->input('add_person');

        //upload Image
        $msg = "";
        $image = $_FILES['image']['name'];
        $target = "images/".basename($image);

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
             $msg = "Image uploaded successfully";
          }else{
             $msg = "Failed to upload image";
          }

        $update_data = "UPDATE information SET country='$country',category='$category',
         name='$name',add_person = '$add_person',image='$image' WHERE id = $id ";
        $run_data = DB::select($update_data);

        $session_email = $request->input('email');

        $view_data = "SELECT * FROM information";
        $run_view_data = DB::select($view_data);
        $data = $run_view_data;

        return view('dashboard',compact('session_email','data'));
        
    }
}
