<?php if(session('success')): ?>
	<div class="alert alert-success alert-dismissible" role='alert'>
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	     <?php echo e(session('success')); ?>

	</div>
<?php endif; ?>

<?php if(session('insert')): ?>
	<div class="alert alert-success alert-dismissible" role='alert'>
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	     <?php echo e(session('insert')); ?>

	</div>
<?php endif; ?>

<?php if(session('delete')): ?>
	<div class="alert alert-success alert-dismissible" role='alert'>
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	     <?php echo e(session('delete')); ?>

	</div>
<?php endif; ?>

<?php if(session('error')): ?>
	<div class="alert alert-danger alert-dismissible" role='alert'>
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	     <?php echo e(session('error')); ?>

	</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel_Search\laravel\resources\views/alert.blade.php ENDPATH**/ ?>