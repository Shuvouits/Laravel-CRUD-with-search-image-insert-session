<!DOCTYPE html>
<html>
<head>
	<title>Laravel Search Application With JavaScript</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">
				<h4 class="text-center" style="font-weight: bold">Laravel Search Application With JavaScript</h4>
			</div>
			<div class="col-md-12">
				<input type="text" id="myInput" onkeyup="myFunction()" placeholder=" Search for names.." title="Type in a name">
				<br>
				<br>
				<br>
				<table class="table table-bordered table-hover table-striped" id="myTable">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th class="text-center">Name</th>
							<th class="text-center">E-Mail</th>
							<th class="text-center">Phone</th>
							<th class="text-center">Division</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $run_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center"><?php echo e($data->id); ?></td>
							<td class="text-center"><?php echo e($data->name); ?></td>
							<td class="text-center"><?php echo e($data->email); ?></td>
							<td class="text-center"><?php echo e($data->phone); ?></td>
							<td class="text-center"><?php echo e($data->division); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</tbody>
					
				</table>
			</div>
		</div>
	</div>



	<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel_Search\laravel\resources\views/search.blade.php ENDPATH**/ ?>